module.exports = {
  Articles: require("./article")
};
